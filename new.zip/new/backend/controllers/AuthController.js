const UserModel = require('../models/UserModel');
const jwt = require('jsonwebtoken')
const AuthController = {
    async login(req, res) {
        const { email, password  } = req.body;

        try {
            const user = await UserModel.findUserByEmailAndPassword(email, password);

            if (user) {
                // User found, send success response
                const id=user.user_id;
                const token=jwt.sign({id},"jwtsecretKey",{expiresIn:300});
                res.status(200).json({ message: 'Login successful', user,token});
            } else {
                // User not found or incorrect credentials, send error response
                res.status(401).json({ error: 'Invalid email or password' });
            }
        } catch (error) {
            // Error handling
            console.error('Error during login:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    },
    async checkAuth(req,res){
        try{
        const token = req.headers['access-token'];
        if(token){
            res.status(200).json('Authenticated');
        }
        else{
            res.status(200).json('Not Authenticated');
        }
        }
        catch(error){
            res.status(500).json({ error: 'Internal server error' });
        }
        
    }
};

module.exports = AuthController;
