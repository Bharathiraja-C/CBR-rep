const UserModel = require('../models/UserModel');

const CertificationController = {
    async addCertifications(req, res) {
        const userId = req.params.userId;
        const certificationData = req.body;

        try {
            const { skills , projects , certifications} = certificationData;
            console.log('certifications :',certificationData );
            await UserModel.addCertifications(userId, certifications );
            await UserModel.addProjects(userId, projects );
            await UserModel.addSkills(userId, skills );

            res.status(201).json({ message: 'Certifications added successfully' });
        } catch (error) {
            console.error('Error adding certifications:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }
};

module.exports = CertificationController;
