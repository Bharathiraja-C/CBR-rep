// routes.js

const express = require('express');
const router = express.Router();
const CertificationController = require('../controllers/CertificationController');
const UserController = require('../controllers/UserController');

// Route for adding certifications
router.post('/add-certifications/:userId', CertificationController.addCertifications);
router.get('/users-details/:userId', UserController.getUserDetails);

module.exports = router;
