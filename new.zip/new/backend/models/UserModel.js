// userModel.js
const { Pool } = require('pg');
const bcrypt = require('bcrypt');


const pool = new Pool({
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT
});

pool.connect()
  .then(() => console.log('Connected to PostgreSQL database'))
  .catch(err => console.error('Error connecting to PostgreSQL database:', err));

const UserModel = {
  async createUser(email, Password ,username, address, phone, role, designation) {
    try {
      const query = {
        text: 'INSERT INTO users (email, password, username, address, phone, role, designation) VALUES ($1, $2, $3, $4, $5, $6, $7)',
        values: [email, Password, username, address, phone, role, designation],
    };

      await pool.query(query);
    } catch (error) {
      throw error;
    }
  },

  async findUserByEmailAndPassword(email,password) {
    const query = {
      text: 'SELECT * FROM users WHERE email = $1 and password= $2',
      values: [email,password],
    };

    try {
      const result = await pool.query(query);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  async getUserByEmail(email){
    const query = {
      text: 'SELECT * FROM users WHERE email = $1',
      values: [email],
    };

    try {
      const result = await pool.query(query);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },

  async comparePassword(user, password) {
    try {
      // Compare the provided password with the hashed password stored in the database
      const passwordMatch = await bcrypt.compare(password, user.password);
      return passwordMatch;
    } catch (error) {
      throw error;
    }
  },

  async updatePassword(email, newPassword) {
    try {
      // Hash the new password
      //const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update the password in the database
      const query = {
        text: 'UPDATE users SET password = $1 WHERE email = $2',
        values: [newPassword, email],
      };

      await pool.query(query);
    } catch (error) {
      throw error;
    }
  },
  async addSkills(userId, skills) {
    try {
      const promises = skills.map(skill => {
        const query = {
          text: 'INSERT INTO Skills (id, user_id, skillName, proficiencyLevel) VALUES ($1, $2, $3, $4)',
          values: [skill.id, userId, skill.skillName, skill.proficiencyLevel],
        };
        return pool.query(query);
      });

      await Promise.all(promises);
    } catch (error) {
      throw error;
    }
  },

  async addProjects(userId, projects) {
    try {
      const promises = projects.map(project => {
        const query = {
          text: 'INSERT INTO Projects (id, user_id, projectName, projectDescription, projectExperience) VALUES ($1, $2, $3, $4, $5)',
          values: [project.id, userId, project.projectName, project.projectDescription, project.projectExperience],
        };
        return pool.query(query);
      });

      await Promise.all(promises);
    } catch (error) {
      throw error;
    }
  },

  async addCertifications(userId, certifications) {
    try {
      const promises = certifications.map(certification => {
        const query = {
          text: 'INSERT INTO Certifications (id, user_id, certificationName, certificationFile) VALUES ($1, $2, $3, $4)',
          values: [certification.id, userId, certification.certificationName, certification.certificationFile],
        };
        return pool.query(query);
      });

      await Promise.all(promises);
    } catch (error) {
      throw error;
    }
  },
  async getUserDetails(userId) {
    try {
        const certificationsQuery = {
            text: 'SELECT * FROM certifications WHERE user_id = $1',
            values: [userId],
        };

        const skillsQuery = {
            text: 'SELECT * FROM skills WHERE user_id = $1',
            values: [userId],
        };

        const projectsQuery = {
            text: 'SELECT * FROM projects WHERE user_id = $1',
            values: [userId],
        };
        const certificationsResult = await pool.query(certificationsQuery);
        const skillsResult = await pool.query(skillsQuery);
        const projectsResult = await pool.query(projectsQuery);
       const userDetails = {
  certifications: certificationsResult.rows[0],
  skills: skillsResult.rows[0],
  projects: projectsResult.rows[0]
};


        return userDetails;
    } catch (error) {
        throw error;
    }
}

};

module.exports = UserModel;
