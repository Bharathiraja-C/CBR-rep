import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './Pages/Login';
import UpdatePassword from './Pages/UpdatePassword';
import UserCreation from './Pages/UserCreation';
import AddCertifications from './Pages/addCertifications';
import UserDetails from './Pages/UserDetails';
import { useParams } from 'react-router-dom'; 

const App = () => {

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route
          path="/create-user"
          element={<ProtectedAddUser />}
        />
        <Route path="/update-password" element={<UpdatePassword />} />
        <Route path="/add-certifications/:userId" element={<ProtectedAddCertifications />} />
        <Route path="/users/:userId" element={<AddWithUserId/>}/>
      </Routes>
    </Router>
  );
};

const ProtectedAddCertifications = () => {
  const isAuthenticated = !!localStorage.getItem('token');
  if(localStorage.getItem("role")!=='admin'){
    return isAuthenticated ? <AddCertificationsWithUserId /> : <Navigate to="/" />;
}
  else{
    return <Navigate to="/" />;
  }
};
const ProtectedAddUser = () => {
  const isAuthenticated = !!localStorage.getItem('token');

  if(localStorage.getItem("role")==='admin'){
      return isAuthenticated ? <UserCreation /> : <Navigate to="/" />;
  }
  else{
      return <Navigate to="/" />;
  }

};
const AddCertificationsWithUserId = () => {
  const { userId } = useParams(); 
  return <AddCertifications userId={userId} />;
};
const AddWithUserId = () => {
  const { userId } = useParams(); 
  return <UserDetails userId={userId} />;
};
export default App;
