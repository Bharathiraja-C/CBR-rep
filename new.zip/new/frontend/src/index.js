import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import NavComponent from './components/NavComponent';
import Sidebar from './components/Sidebar';
import reportWebVitals from './reportWebVitals';

ReactDOM.render(
  <React.StrictMode>
    <NavComponent />
    <div className="sidebar-wrapper">
      <Sidebar />
    </div>
    <div className="content-wrapper">
      <App />
    </div>
  </React.StrictMode>,
  document.getElementById('root')
);

reportWebVitals();
