import React, { useState, useEffect } from 'react';
import UserService from '../Services/UserService'; // Import the UserService
import { Table } from 'react-bootstrap';

const UserDetails = ({ userId }) => {
  const [userDetails, setUserDetails] = useState({});

  useEffect(() => {
    // Fetch user details using the provided userId
    const fetchUserDetails = async () => {
      try {
        const userData = await UserService.getUserDetails(userId);
        console.log(userData);
        setUserDetails(userData);
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };

   // fetchUserDetails();
  }, [userId]);

  return (
    <div>
   {userDetails.certification.id}
      <h2>User Details</h2>
      {userDetails && (
        <div>
          <h3>Skills</h3>
          {userDetails.skills && userDetails.skills.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>Skill Name</th>
                  <th>Proficiency Level</th>
                </tr>
              </thead>
              <tbody>
                {userDetails.skills.map((skill, index) => (
                  <tr key={index}>
                    <td>{skill.skillName}</td>
                    <td>{skill.proficiencyLevel}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No skills found</p>
          )}

          <h3>Projects</h3>
          {userDetails.projects && userDetails.projects.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>Project Name</th>
                  <th>Project Description</th>
                  <th>Project Experience</th>
                </tr>
              </thead>
              <tbody>
                {userDetails.projects.map((project, index) => (
                  <tr key={index}>
                    <td>{project.projectName}</td>
                    <td>{project.projectDescription}</td>
                    <td>{project.projectExperience}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No projects found</p>
          )}

          <h3>Certifications</h3>
          {userDetails.certifications && userDetails.certifications.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>Certification Name</th>
                  <th>Certification File</th>
                </tr>
              </thead>
              <tbody>
                {userDetails.certifications.map((certification, index) => (
                  <tr key={index}>
                    <td>{certification.certificationName}</td>
                    <td>{certification.certificationFile}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No certifications found</p>
          )}
        </div>
      )}
    </div>
  );
};

export default UserDetails;
