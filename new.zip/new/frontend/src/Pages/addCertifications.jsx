import React, { useState } from 'react';
import { Button, Form } from 'react-bootstrap';
import UserService from '../Services/UserService'; // Import UserService
import './Login.css';

const AddCertification = ({ userId }) => {
    const [skills, setSkills] = useState([]);
    const [projects, setProjects] = useState([]);
    const [certifications, setCertifications] = useState([]);
    const [showRemoveSkillButton, setShowRemoveSkillButton] = useState(false);
    const [showRemoveProjectButton, setShowRemoveProjectButton] = useState(false);
    const [showRemoveCertificationButton, setShowRemoveCertificationButton] = useState(false);

    const handleSkillChange = (index, key, value) => {
        const updatedSkills = [...skills];
        updatedSkills[index][key] = value;
        setSkills(updatedSkills);
    };

    const handleProjectChange = (index, key, value) => {
        const updatedProjects = [...projects];
        updatedProjects[index][key] = value;
        setProjects(updatedProjects);
    };

    const handleCertificationChange = (index, key, value) => {
        const updatedCertifications = [...certifications];
        updatedCertifications[index][key] = value;
        setCertifications(updatedCertifications);
    };

    const addSkill = () => {
        setSkills([
            ...skills,
            { 
                id: Math.random().toString(36).substr(2, 9), 
                skillName: '', 
                proficiencyLevel: ''
            }
        ]);
        setShowRemoveSkillButton(true); // Show remove skill button after adding a skill
    };

    const addProject = () => {
        setProjects([
            ...projects,
            { 
                id: Math.random().toString(36).substr(2, 9), 
                projectName: '', 
                projectDescription: '', 
                projectExperience: ''
            }
        ]);
        setShowRemoveProjectButton(true); // Show remove project button after adding a project
    };

    const addCertification = () => {
        setCertifications([
            ...certifications,
            { 
                id: Math.random().toString(36).substr(2, 9), 
                certificationName: '', 
                certificationFile: ''
            }
        ]);
        setShowRemoveCertificationButton(true); // Show remove certification button after adding a certification
    };

    const removeSkill = (index) => {
        const updatedSkills = [...skills];
        updatedSkills.splice(index, 1);
        setSkills(updatedSkills);
        if (updatedSkills.length === 0) {
            setShowRemoveSkillButton(false); // Hide remove skill button if no skills left
        }
    };

    const removeProject = (index) => {
        const updatedProjects = [...projects];
        updatedProjects.splice(index, 1);
        setProjects(updatedProjects);
        if (updatedProjects.length === 0) {
            setShowRemoveProjectButton(false); // Hide remove project button if no projects left
        }
    };

    const removeCertification = (index) => {
        const updatedCertifications = [...certifications];
        updatedCertifications.splice(index, 1);
        setCertifications(updatedCertifications);
        if (updatedCertifications.length === 0) {
            setShowRemoveCertificationButton(false); // Hide remove certification button if no certifications left
        }
    };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        const userData = { skills, projects, certifications };
        await UserService.addCertification(userId, userData);
        console.log('Skills, Projects, and Certifications added successfully');
    } catch (error) {
        console.error('Error adding Skills, Projects, and Certifications:', error);
       
    }
};


    return (
        <div className="form-head">
            <center className="login-head">Tech Stack Details</center>
            <Form onSubmit={handleSubmit}>
                <div>
                    <label style={{ fontSize: "20px" }}>Add Skills</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <Button variant="success" onClick={addSkill}>+</Button>
                </div>
                {skills.map((skill, skillIndex) => (
                    <div key={skill.id}>
                        <Form.Group controlId={`skillName${skillIndex}`}>
                            <Form.Label>Skill Name</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter skill name"
                                value={skill.skillName}
                                onChange={(e) => handleSkillChange(skillIndex, 'skillName', e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId={`proficiencyLevel${skillIndex}`}>
                            <Form.Label>Proficiency Level</Form.Label>
                            <br />
                            <Form.Control
                                as="select"
                                value={skill.proficiencyLevel}
                                onChange={(e) => handleSkillChange(skillIndex, 'proficiencyLevel', e.target.value)}
                            >
                                <option value="">Select proficiency level</option>
                                <option value="Beginner">Beginner</option>
                                <option value="Intermediate">Intermediate</option>
                                <option value="Advanced">Advanced</option>
                            </Form.Control>
                        </Form.Group>
                        <br />
                        {showRemoveSkillButton && <Button variant="danger" onClick={() => removeSkill(skillIndex)}>-</Button>}
                    </div>
                ))}
                <div>
                    <br/>
                    <label style={{ fontSize: "20px" }}>Add Projects</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <Button variant="success" onClick={addProject}>+</Button>
                </div>
                {projects.map((project, projectIndex) => (
                    <div key={project.id}>
                        <Form.Group controlId={`projectName${projectIndex}`}>
                            <Form.Label>Project Name</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter project name"
                                value={project.projectName}
                                onChange={(e) => handleProjectChange(projectIndex, 'projectName', e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId={`projectDescription${projectIndex}`}>
                            <Form.Label>Project Description</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter project description"
                                value={project.projectDescription}
                                onChange={(e) => handleProjectChange(projectIndex, 'projectDescription', e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId={`projectExperience${projectIndex}`}>
                            <Form.Label>Project Experience</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter project experience"
                                value={project.projectExperience}
                                onChange={(e) => handleProjectChange(projectIndex, 'projectExperience', e.target.value)}
                            />
                        </Form.Group>
                        <br />
                        {showRemoveProjectButton && <Button variant="danger" onClick={() => removeProject(projectIndex)}>-</Button>}
                    </div>
                ))}
                <div>
                    <br/>
                    <label style={{ fontSize: "20px"}}>Add Certifications</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <Button variant="success" onClick={addCertification} >+</Button>
                </div>
                {certifications.map((certification, certificationIndex) => (
                    <div key={certification.id}>
                        <Form.Group controlId={`certificationName${certificationIndex}`}>
                            <Form.Label>Certification Name</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter certification name"
                                value={certification.certificationName}
                                onChange={(e) => handleCertificationChange(certificationIndex, 'certificationName', e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId={`certificationFile${certificationIndex}`}>
                            <Form.Label>Certification File (Link or Drive)</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter certification file link"
                                value={certification.certificationFile}
                                onChange={(e) => handleCertificationChange(certificationIndex, 'certificationFile', e.target.value)}
                            />
                        </Form.Group>
                        <br />
                        {showRemoveCertificationButton && <Button variant="danger" onClick={() => removeCertification(certificationIndex)}>-</Button>}
                    </div>
                ))}
                <br />
                <Button type="submit">Submit</Button>
            </Form>
        </div>
    );
};

export default AddCertification;
