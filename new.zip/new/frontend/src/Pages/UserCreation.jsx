import React, { useState } from 'react';
import { Button, Form } from 'react-bootstrap';
import UserService from '../Services/UserService';

const CreateUser = () => {
    const [email, setEmail] = useState('');
    const [username, setUsername] = useState('');
    const [address, setAddress] = useState('');
    const [phone, setPhone] = useState('');
    const [role, setRole] = useState('');
    const [designation, setDesignation] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await UserService.createUser(email, username, address, phone, role, designation);
            console.log('User created successfully:', result);
            // Handle success (e.g., show a success message)
        } catch (error) {
            console.error('Error creating user:', error);
            // Handle error (e.g., display an error message)
        }
    };

    return (
        <div className="form-head">
            <center className="create-user-head">Create New User</center>
            <br />
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                        type="email"
                        placeholder="Enter email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </Form.Group>

                <Form.Group controlId="formBasicUsername">
                    <Form.Label>Username</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Enter username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                </Form.Group>

                <Form.Group controlId="formBasicAddress">
                    <Form.Label>Address</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Enter address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                    />
                </Form.Group>

                <Form.Group controlId="formBasicPhone">
                    <Form.Label>Phone</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Enter phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                    />
                </Form.Group>

                <Form.Group controlId="formBasicRole">
                            <Form.Label>Role</Form.Label>
                            <br />
                            <Form.Control
				                as='select'
                                value={role}
                                onChange={(e) => setRole(e.target.value)}
                            >
                                <option value="">Select role</option>
                       	 	<option value="Admin">Admin</option>
                        	<option value="User">User</option>
                            </Form.Control>
       
                 </Form.Group>

                <Form.Group controlId="formBasicDesignation">
                    <Form.Label>Designation</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Enter designation"
                        value={designation}
                        onChange={(e) => setDesignation(e.target.value)}
                    />
                </Form.Group>

                <Button className="Button" type="submit">Create User</Button>
            </Form>
        </div>
    );
};

export default CreateUser;
