const UserModel = require('../models/UserModel');

const CertificationController = {
    async addCertifications(req, res) {
        const mail=null;
        const userId = req.params.userId;
        const certificationData = req.body;

        try {
            const { skills} = certificationData; // Extract skillId
            console.log('certifications:', certificationData);
            await UserModel.addCertifications(userId, skills.certifications, skills.id); // Pass skillId to addCertifications
            await UserModel.addProjects(userId, skills.projects, skills.id); // Pass skillId to addProjects
            await UserModel.addSkills(userId, skills); // Pass skillId to addSkills
            res.status(201).json({ message: 'Certifications added successfully' });
        } catch (error) {
            console.error('Error adding certifications:', error);
            res.status(500).json({ mail, error: 'Internal server error' });
        }
    },
    async updateStatus(req, res) {
            const userId = req.params.userId;
            const newStatus = req.body.status;
    
            try {
                await UserModel.updateCertificationStatus(userId, newStatus);
                res.status(200).json({ message: 'Certification status updated successfully' });
            } catch (error) {
                console.error('Error updating certification status:', error);
                res.status(500).json({ error: 'Internal server error' });
            }
        }
};

module.exports = CertificationController;
