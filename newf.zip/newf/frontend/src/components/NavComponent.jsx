import React, { useEffect, useState } from 'react';
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import './NavComponent.css';
import { useLocation } from 'react-router-dom';

const NavComponent = () => {
  // State to store the profile name
  const [username,setUsername]=useState("ggg");
  useEffect( ()=>{
    setUsername(localStorage.getItem('username'));
    console.log(username)
  },[]);
  // Update the username when profileName prop changes

  const location = useLocation();
  useEffect(() => {
    console.log("location-state",location.state)
  }, [])  
 

  return (
    <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
      <Container className="d-flex justify-content-center align-items-center">
        <img src="https://www.shutterstock.com/image-vector/leadership-logo-success-education-vector-260nw-1619427685.jpg" width={80} alt="no photo" />
        <Navbar.Brand href="#home" style={{ fontSize: '2.5rem', fontWeight: 'bold', marginLeft: '10px', color: 'black' }}>Skills Matrix</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="ml-auto">
            <Nav.Link href="/" className="profile-icon">
              <i className="fa-solid fa-user"></i>
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
        <span style={{ color: 'black' }}>{localStorage.getItem('username')}</span>
      </Container>
    </Navbar>
  );
};

export default NavComponent;
