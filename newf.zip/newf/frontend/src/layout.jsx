import React from "react";
import { Outlet } from "react-router-dom";
import NavComponent from "./components/NavComponent";
import Sidebar from "./components/Sidebar";

const Layout = () => {
  return (
    <>
      <NavComponent />
      <div className="sidebar-wrapper">
        <Sidebar />
      </div>
      <div className="content-wrapper">
        <Outlet />
      </div>
    </>
  );
};

export default Layout;
